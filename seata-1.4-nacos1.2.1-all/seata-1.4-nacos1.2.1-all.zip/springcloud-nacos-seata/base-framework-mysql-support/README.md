# base-framework-mysql-support

> 基础包，集成 mysql connector 、druid、mybatis（mybatis-plus），其他子模块依赖该模块，免去每个子模块中配置

## 使用方法

1. pom中引用该模块
2. spring 扫描 'com.work'
3. propert中配置druid 数据源

